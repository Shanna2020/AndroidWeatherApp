package com.example.weatherapiassignment;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;


public class MainActivity extends AppCompatActivity {

    TextView weatherCity;
    TextView dateTime;
    TextView descriptionView;
    TextView currentTemp;
    TextView tempView;
    ImageView imageIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        weatherCity = findViewById(R.id.cityName);
        dateTime= findViewById(R.id.dateTimeView);
        imageIcon = findViewById(R.id.iconImageView);
        currentTemp = findViewById(R.id.currentTmpView);
        descriptionView = findViewById(R.id.descriptionView);
        tempView = findViewById(R.id.TmpView);
        populateWeatherData();


    }

    private void populateWeatherData() {
        String url="https://api.openweathermap.org/data/2.5/weather?q=scarborough&appid=7bfc7fb44504c02f0d0a7e671127c097";

        DecimalFormat formatTemp = new DecimalFormat("#");
        // Request JSON data from the provided URL and display response
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {

                        Long dt=response.getLong("dt");
                        JSONArray weatherArray= response.getJSONArray("weather");
                        String name= response.getString("name");
                        JSONObject weather=weatherArray.getJSONObject(0);
                        JSONObject main= response.getJSONObject("main");
                        Double temp=(Double) main.getDouble("temp") - 275.15 ;
                        Double temp_min=(Double) main.getDouble("temp_min")-275.15;
                        Double temp_max=(Double) main.getDouble("temp_max")-275.15;
                        Double feels_like = (Double) main.getDouble( "feels_like")-275.15;
                        String description = (String) weather.getString("description");
                        String icon = (String) weather.getString("icon");

                        SimpleDateFormat format = new SimpleDateFormat("MMM-dd hh:mma");
                        format.setTimeZone(TimeZone.getDefault());
                        String dateString = format.format(new Date(dt*1000));

                        Picasso.get()
                                .load("https://openweathermap.org/img/w/"+icon+".png")
                                .resize(450,450)
                                .placeholder(R.drawable.defaulticon)
                                .into(imageIcon);

                        weatherCity.setText(" " + name);
                        currentTemp.setText(" " + formatTemp.format(temp) + "C");
                        dateTime.setText("" + dateString);
                        descriptionView.setText(""+description);
                        tempView.setText("Feel Like: " + formatTemp.format(feels_like)+"   Max Temp: "+ formatTemp.format(temp_max) +"  Min Temp: " + formatTemp.format(temp_min));

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        }

        ); //JsonObjectRequest

        //Add request to a new request queue
        Volley.newRequestQueue(this).add(jsonObjectRequest);
    }
}